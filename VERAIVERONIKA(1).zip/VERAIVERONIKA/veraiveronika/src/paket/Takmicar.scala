package paket

class Takmicar(var imeprezime: String, var indeks: String, var bodovi : Double) {
  def getIme() : String = imeprezime
  def getIndeks () : String = indeks
  def getBodovi () : Double = bodovi

  def setIme(imeprezime: String) = {
    this.imeprezime = imeprezime
  }

  def setIndeks(indeks: String) = {
    this.indeks = indeks
  }

  def setBodovi(bodovi : Double) = {
    this.bodovi = bodovi
  }

  override def toString(): String = {
    return this.imeprezime + " " + this.indeks + ": " + this.bodovi
  }



}
