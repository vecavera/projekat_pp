AUTORI: 
------------
Vera Milosavljevic, mr15
Veronika Miljakovic mr15235

PROGRAMSKI JEZIK:
------------------------------
Scala

KORISCENE TEHNOLOGIJE: 
----------------------------------------
Scala 2.12.3, ScalaFX 2.12.3, Scala Library container 2.12.3

OKRUZENJE:
------------------
Eclipse Scala IDE , verzija 4.7.1.v-2_12-201801021323-2dfe808 ili __________________________________-


POKRETANJE: 
---------------------
Projekat se pokrece tako sto se importuje u Eclipse koji ima instaliran Scala IDE ili u ___________________________________ . Takodje da bi se pokrenulo potrebno je importovati odgovarajucu Scalafx biblioteku. Verzija Scala-e i Scalafx-a se moraju poklopiti!


OPIS:
-------
Kviz predstavlja simulaciju testa iz kursa "Programske paradigme".  

U prvom delu se nalazi formular za prijavu u kom takmicar, pored ostalog, bira da li zeli da radi teorijski kolokvijum ili teorijski ispit.

U drugom delu se nalazi 10 pitanja sa po cetiri ponudjena odgovora. Kada odabere odgovor koji zeli takmicar stiska dugme "DALJE" i prelazi na sledece pitanje.
 Ukoliko ne zeli, takmicar ne mora da da nikakav odgovor. 

U cetvrtom delu:
	Ukoliko je na pocetku odabrao da radi kolokvijum dobija informaciju o broju osvojenih poena, kao i o tome koliko poena mu nedostaje da dobije odredjenu ocenu.
	Ukoliko je na pocetku odabrao da radi ispit dobija informaciju o broju osvojenih poena, kao i o tome da li je polozio ispit i ako jeste sa kojom ocenom.
Nakon toga moze odabrati dugme "UVID" kako bi video gde je sve pogresio ili dugme "KRAJ" kako bi izasao iz kviza.


KONTAKT:
________
Vera : _____________________________________
Veronika: veronika.miljakovic1996@gmail.com