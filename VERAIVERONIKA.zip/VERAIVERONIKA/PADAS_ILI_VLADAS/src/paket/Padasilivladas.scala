package paket

import paket.Pitanja.Pitanja
import scalafx.Includes._
import scalafx.application.JFXApp
import scalafx.application.JFXApp.PrimaryStage
import scalafx.event.ActionEvent
import scalafx.geometry.Pos
import scalafx.scene.Scene
import scalafx.scene.control._
import scalafx.scene.paint.Color._
import scala.io.Source



object Padasilivladas extends JFXApp{


  var takmicar = new Takmicar("", "", 0)



  stage = new PrimaryStage{

    var indikator = 0
    var brojpoena = 0.0
    var j = 0

    title.value = "Padas ili vladas?"
    width = 700
    height = 700



    //PRVA SCENA - SAMO NASLOV I POCETAK KVIZA

    scene = new Scene {



      fill = LightBlue
      val labela = new Label("PADAS ILI VLADAS?")
      {
        alignment = Pos.CENTER
      }
      labela.style="""-fx-font-size: 35pt;
                  -fx-text-fill: #0000ff;
                  -fx-font-weight: bold"""

      labela.layoutX = 50
      labela.layoutY = 250
      labela.minHeight = 30
      labela.minWidth = 600

      var pocni = new Button ()
      {  text = "POCNI SA RADOM"
        prefWidth=320
        prefHeight=100
        style="""-fx-background-color:  linear-gradient(#bf90ee, #ffc0cb);

      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 15;"""

      }

      pocni.layoutX = (180)
      pocni.layoutY = (470)

      pocni.onAction = (e:ActionEvent) => {

        // DRUGA SCENA- UPISIVANJE PODATAKA

        scene  = new Scene{


          fill = LightCoral

          val imeIprezime = new Label("Ime i prezime:")
          imeIprezime.style="""-fx-font-size: 15pt;
                             -fx-text-fill:  #0000ff;"""
          imeIprezime.layoutX = (80)
          imeIprezime.layoutY = (50)
          val imePrezime = new TextField
          imePrezime.layoutX = (440)
          imePrezime.layoutY = (50)
          val brojIndeksa = new Label("Broj indeksa:")
          brojIndeksa.style="""-fx-font-size: 15pt;
                  -fx-text-fill:  #0000ff;"""
          brojIndeksa.layoutX = (80)
          brojIndeksa.layoutY = (100)
          val indeks = new TextField
          indeks.layoutX= (440)
          indeks.layoutY= (100)
          val odabir = new Label("Odaberite sta zelite da radite:")
          odabir.style="""-fx-font-size: 15pt;
                  -fx-text-fill:  #0000ff;"""
          odabir.layoutX = (80)
          odabir.layoutY = (150)
          val recenica = new Label("Ukoliko je odgovor na prethodno pitanje bilo ISPIT popunite sledeca polja:")
          recenica.style="""-fx-font-size: 13pt;
                  -fx-text-fill:  #0000ff;"""

          val grupa = new ToggleGroup()
          var kolokvijum = new RadioButton()
          {
            text = "KOLOKVIJUM"
            prefWidth=150
            prefHeight=40
            style="""-fx-background-color: linear-gradient(#bf90ee, #ffc0cb);
      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 15px;
      -fx-padding: 5 10 5 10;"""

            fill <== when (hover) choose LightPink otherwise LightBlue
            toggleGroup=grupa
          }

          var ispit = new RadioButton()
          {

            text = "ISPIT"
            prefWidth=150
            prefHeight=40
            style="""-fx-background-color: linear-gradient(#bf90ee, #ffc0cb);
      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 15px;
      -fx-padding: 5 10 5 10;"""

            fill <== when (hover) choose LightPink otherwise LightBlue
            toggleGroup = grupa
          }
          kolokvijum.layoutX_=(175)
          kolokvijum.layoutY_=(200)
          ispit.layoutX_=(375)
          ispit.layoutY_=(200)
          recenica.layoutX = (60)
          recenica.layoutY = (250)
          val brojPoenaT = new Label ("Broj poena na teorijskom kolokvijumu:")
          brojPoenaT.style="""-fx-font-size: 15pt;
                  -fx-text-fill:  #0000ff;"""
          brojPoenaT.layoutX_=(80)
          brojPoenaT.layoutY= (300)
          val brojT = new TextField
          brojT.layoutX = (500)
          brojT.layoutY = (300)
          brojT.setPrefWidth(50)
          val brojPoenaP = new Label ("Broj poena na prakticnom kolokvijumu:")
          brojPoenaP.style="""-fx-font-size: 15pt;
                  -fx-text-fill:  #0000ff;"""
          brojPoenaP.layoutX = (80)
          brojPoenaP.layoutY = (350)
          val brojP = new TextField
          brojP.layoutX = (500)
          brojP.layoutY = (350)
          brojP.setPrefWidth(50)
          val brojPoenaI = new Label("Broj poena na prakticnom ispitu:")
          brojPoenaI.style="""-fx-font-size: 15pt;
                  -fx-text-fill:  #0000ff;"""
          brojPoenaI.layoutX = (80)
          brojPoenaI.layoutY = (400)
          val brojI = new TextField
          brojI.layoutX = (500)
          brojI.layoutY = (400)
          brojI.setPrefWidth(50)
          val srecno = new Label("SRECNO!")
          srecno.style ="""-fx-font-size: 15pt;
                  -fx-text-fill:  #0000ff;"""
          srecno.layoutX = (300)
          srecno.layoutY= (470)
          val start = new Button()
          {
            text = "START"
            prefWidth=200
            prefHeight=80
            style="""-fx-background-color: linear-gradient(#bf90ee, #ffc0cb);
      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 15px;
      -fx-padding: 5 10 5 10;"""

            fill <== when (hover) choose LightPink otherwise LightBlue

          }
          start.layoutX = (250)
          start.layoutY = (520)

          var dugme = 0   //oznacava da li ste odabrali ispit ili kolokvijum
          var poeniT = 0.0
          var poeniP =0.0
          var poeniI=0.0
          var poeni =0.0

          kolokvijum.onAction = (e:ActionEvent) => {
            dugme = 1

          }

          ispit.onAction = (e:ActionEvent) => {
            dugme = 2

          }



          start.onAction = (e:ActionEvent) => {


            takmicar.setIme(imePrezime.getText)

            takmicar.setIndeks(indeks.getText)
            if(dugme == 2)
            {
              if(brojT.getText=="")
                poeniT=0
              else
                poeniT = brojT.getText.toInt
              if(brojP.getText=="")
                poeniP=0
              else
                poeniP= brojP.getText.toInt
              if(brojI.getText=="")
                poeniI=0
              else
                poeniI=brojI.getText.toInt
              takmicar.setBodovi(poeniP + poeniI + poeniT)
            }



            //TRECA SCENA - U OVOJ SCENI SE ODGOVARA NA PITANJA

            scene = new Scene {


              fill = LightCoral

              val tog = new ToggleGroup()

              val tacnoiline = new Label()

              //AKO STE ODABRALI KOLOKVIJUM UCITAVAMO PITANJA IZ DATOTEKE PITANJA1.TXT

              var listaPitanja = scala.collection.mutable.MutableList[Pitanja]()
              var listaPitanja2 = scala.collection.mutable.MutableList[Pitanja]()


              if(dugme==1)
              {
                val linije = Source.fromFile("pitanja1.txt")("UTF-8").getLines()
                var lista = scala.collection.mutable.MutableList[String]()
                for (linija <- linije)
                  lista+=(linija)


                var velicina = lista.size
                var i = 0

                while (i<velicina){
                  var pitanje = new Pitanja ("","","","","")
                  pitanje.setIme(lista(i))
                  pitanje.setTacanOdgovor(lista(i+1))
                  pitanje.setDrugi(lista(i+2))
                  pitanje.setTreci(lista(i+3))
                  pitanje.setCetvrti(lista(i+4))
                  listaPitanja+=pitanje
                  i+=5
                }

                var listaPitanja5=scala.util.Random.shuffle(listaPitanja)
                listaPitanja2 = listaPitanja5.take(10)

                // gotovo ucitavanje

              }


              //U SUPROTNOM UCITAVAMO IZ DATOTEKE ZA ISPIT,A TO JE PITANJA.TXT

              else
              {
                val linije = Source.fromFile("pitanja.txt")("UTF-8").getLines()
                var lista = scala.collection.mutable.MutableList[String]()

                for (linija <- linije)
                  lista+=(linija)


                var i = 0
                var velicina = lista.size

                while (i<velicina ){
                  var pitanje = new Pitanja ("","","","","")
                  pitanje.setIme(lista(i))
                  pitanje.setTacanOdgovor(lista(i+1))
                  pitanje.setDrugi(lista(i+2))
                  pitanje.setTreci(lista(i+3))
                  pitanje.setCetvrti(lista(i+4))
                  listaPitanja+=pitanje
                  i+=5
                }

                var listaPitanja5=scala.util.Random.shuffle(listaPitanja)
                listaPitanja2 = listaPitanja5.take(10)

                // gotovo ucitavanje

              }




              val listaOdgovora = scala.collection.mutable.MutableList[String](listaPitanja2(j).tacanOdgovor.toString(),listaPitanja2(j).drugi.toString(),listaPitanja2(j).treci.toString(),listaPitanja2(j).cetvrti.toString())


              val listaOdgovora2=scala.util.Random.shuffle(listaOdgovora)

              var kliknuto = scala.collection.mutable.MutableList[Int]()
              var odgovori = scala.collection.mutable.MutableList[String] ()

              var dugme1 = new RadioButton()
              {
                text = listaOdgovora2(0)
                prefWidth=270
                prefHeight=100
                style="""-fx-background-color:  linear-gradient(#bf90ee, #ffc0cb);

      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 10;"""

                toggleGroup = tog

              }

              dugme1.layoutX=50
              dugme1.layoutY=200
              dugme1.setWrapText(true)



              var dugme2 = new RadioButton ()
              {  text = listaOdgovora2(1)

                prefWidth=270
                prefHeight=100
                style="""-fx-background-color:  linear-gradient(#bf90ee, #ffc0cb);

      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 10;"""
                toggleGroup = tog
              }
              dugme2.layoutX = 400
              dugme2.layoutY = 200
              dugme2.setWrapText(true)

              var dugme3 = new RadioButton ()
              {  text = listaOdgovora2(2)
                prefWidth=270
                prefHeight=100
                style="""-fx-background-color:  linear-gradient(#bf90ee, #ffc0cb);

      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 10;"""
                toggleGroup = tog
              }
              dugme3.layoutX = 50
              dugme3.layoutY = 400
              dugme3.setWrapText(true)

              var dugme4 = new RadioButton ()
              {  text = listaOdgovora2(3)
                prefWidth=270
                prefHeight=100
                style="""-fx-background-color:  linear-gradient(#bf90ee, #ffc0cb);

      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 10;"""
                toggleGroup = tog
              }
              dugme4.layoutX = 400
              dugme4.layoutY = 400
              dugme4.setWrapText(true)

              val dugmedalje = new Button("DALJE")
              {
                alignment = Pos.Center
                prefWidth=150
                prefHeight=40
                style="""-fx-background-color: linear-gradient(#bf90ee, #ffc0cb);
      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 15px;
      -fx-padding: 5 10 5 10;"""
                fill <== when (hover) choose LightPink otherwise LightBlue
              }

              dugmedalje.layoutX = 250
              dugmedalje.layoutY = 550
              dugmedalje.minHeight = 50
              dugmedalje.minWidth = 50

              var indeks=j+1

              var labela = new Label( indeks + ". " + listaPitanja2(j).toString())
              {
                alignment=Pos.CENTER
              }
              labela.layoutX = 60
              labela.layoutY = 100

              labela.setMaxWidth(600)
              labela.setWrapText(true)
              labela.style ="""-fx-font-size: 15pt;
                            -fx-text-fill: #0000ff;"""
              
              
              var odgovor = ""

              dugme1.onAction = (e:ActionEvent) => {

                if(dugme1.getText == listaPitanja2(j).tacanOdgovor)
                {     indikator = 1

                }
                else
                { indikator = 2
                }

                odgovor = dugme1.getText
                
              }
              
             

              dugme2.onAction = (e:ActionEvent) => {
                if(dugme2.getText == listaPitanja2(j).tacanOdgovor)
                {
                  indikator = 1
                }
                else
                { indikator = 2

                }
                  
                odgovor = dugme2.getText
              
              }

              dugme3.onAction = (e:ActionEvent) => {
                if(dugme3.getText == listaPitanja2(j).tacanOdgovor)

                  indikator = 1


                else
                  indikator = 2

                  odgovor = dugme3.getText
               
              }

              dugme4.onAction = (e:ActionEvent) => {
                if(dugme4.getText == listaPitanja2(j).tacanOdgovor)

                  indikator = 1
                else
                  indikator = 2
                  
                  odgovor = dugme4.getText

            
              }
             
              dugmedalje.onAction = (e:ActionEvent) => {       
                  
              odgovori += odgovor
              
                if(indikator == 1)
                { brojpoena = brojpoena + 2.5

                  kliknuto += indikator
                  indikator =0

                }

                else if(indikator == 2)
                {

                  kliknuto += indikator
                  indikator = 0
                }

                else if(indikator == 0)
                {

                  kliknuto += indikator
                }

                if(j==9)
                {
                  if (dugme==2)
                    takmicar.setBodovi(takmicar.getBodovi() + brojpoena)
                  else 
                    takmicar.setBodovi(0+brojpoena)

                  //CETVRTA SCENA - SCENA U KOJOJ DOBIJATE INFORMACIJU KOJI JE VAS REZULTAT,  DA LI STE POLOZILI ILI NE
                  //I KOJU OCENU STE DOBILI


                  scene = new Scene {

                    fill = LightBlue
                    var ocena=0


                    val polozio = new Label ()
                    {

                      alignment = Pos.CENTER
                    }
                    polozio.style="""-fx-font-size: 70pt;
                    -fx-text-fill:  #0000ff;
                      -fx-font-weight: bold"""

                    polozio.layoutX = (200)
                    polozio.layoutY = (130)

                    if (dugme==2){
                      if(takmicar.getBodovi()>51 && (poeniT + brojpoena)>18)
                      {
                        polozio.setText("VLADAS!")


                      }
                      else
                      {

                        polozio.setText("PADAS!")
                      }

                      //OBRACUNAVANJE OCENE
                      if(takmicar.getBodovi()<51 || (poeniT + brojpoena)<18)
                        ocena=5
                      else if(takmicar.getBodovi()>51 && takmicar.getBodovi()<61)
                        ocena=6
                      else if(takmicar.getBodovi()>61 && takmicar.getBodovi()<71)
                        ocena=7
                      else if(takmicar.getBodovi()>71 && takmicar.getBodovi()<81)
                        ocena=8
                      else if(takmicar.getBodovi()>81 && takmicar.getBodovi()<91)
                        ocena=9
                      else
                        ocena=10

                    }

                    //Broj poena na kolokvijumu moze maksimum za bude 20
                    var bodovikol=0.0
                    if(dugme!=2)
                    { bodovikol=takmicar.getBodovi()*0.8
                      takmicar.setBodovi(bodovikol)

                    }

                    val ImeIprezime= new Label()
                    {
                      alignment = Pos.CENTER
                    }
                    ImeIprezime.style="""-fx-font-size: 20pt;
                  -fx-text-fill:  #0000ff;"""
                    ImeIprezime.layoutX= (70)
                    ImeIprezime.layoutY = (50)
                    ImeIprezime.setText("* " + takmicar.getIme())

                    val rezultat = new Label()
                    {
                      alignment = Pos.CENTER
                    }
                    rezultat.style="""-fx-font-size: 20pt;
                  -fx-text-fill:  #0000ff;"""
                    rezultat.layoutX=(70)
                    rezultat.layoutY = (100)
                    rezultat.setText("* Broj osvojenih poena: " + takmicar.getBodovi())


                    val ocenalabela= new Label()
                    {

                      alignment = Pos.CENTER
                    }


                    if(dugme ==2)
                    {ocenalabela.setText("* Dobili Ste ocenu: " + ocena + "!")
                      ocenalabela.layoutX = (70)
                      ocenalabela.layoutY = (270)
                      ocenalabela.style="""-fx-font-size: 20pt;
                  -fx-text-fill:  #0000ff;"""
                    }
                    else
                    { ocenalabela.setText("* Da biste dobili ocenu 6 potrebno Vam je jos ukupno: " + (51-takmicar.getBodovi()) + "!\n* Da biste dobili ocenu 7 potrebno Vam je jos ukupno " + (61-takmicar.getBodovi()) + "!\n* Da biste dobili ocenu 8 potrebno Vam je jos ukupno " + (71-takmicar.getBodovi()) + "!\n* Da biste dobili ocenu 9 potrebno Vam je jos ukupno " + (81-takmicar.getBodovi()) + "!\n* Da biste dobili ocenu 10 potrebno Vam je jos ukupno: " + (91-takmicar.getBodovi()) + "!")
                      ocenalabela.layoutX = (100)
                      ocenalabela.layoutY = (200)
                      ocenalabela.style="""-fx-font-size: 15pt;
                  -fx-text-fill:  #0000ff;"""

                    }
                    val poruka = new Label()
                    {
                      alignment = Pos.CENTER
                    }
                    poruka.style="""-fx-font-size: 20pt;
                  -fx-text-fill:  #0000ff;"""

                    if(dugme==2)
                    {  if(ocena==5)
                      poruka.setText("* Da biste polozili ispit potrebno je da osvojite:\n\t*ukupno najmanje 51 poen\n\t*od toga najmanje 40% na teoriji(18 poena)\n* Vise srece sledeci put!")
                    else
                      poruka.setText("* Cestitamo na polozenom ispitu!")
                      poruka.layoutX = (70)
                      poruka.layoutY = (320)
                    }

                    else
                    {  poruka.setText("* Srecno u nastavku kursa!")
                      poruka.layoutX = (100)
                      poruka.layoutY = (420)
                    }

                    var kraj = new Button("KRAJ")
                    {
                      alignment = Pos.Center
                      prefWidth=200
                      prefHeight=70
                      style="""-fx-background-color: linear-gradient(#bf90ee, #ffc0cb);
      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 15px;
      -fx-padding: 5 10 5 10;"""
                      fill <== when (hover) choose LightPink otherwise LightBlue

                    }

                    kraj.layoutX = (400)
                    kraj.layoutY = (500)

                    var uvid = new Button("UVID")
                    {
                      alignment = Pos.Center
                      prefWidth=200
                      prefHeight=70
                      style="""-fx-background-color: linear-gradient(#bf90ee, #ffc0cb);
      -fx-background-radius: 5;
      -fx-background-insets: 0,1,2,3,0;
      -fx-text-fill: #0000ff;
      -fx-font-weight: bold;
      -fx-font-size: 15px;
      -fx-padding: 5 10 5 10;"""
                      fill <== when (hover) choose LightPink otherwise LightBlue

                    }

                    uvid.layoutX = (100)
                    uvid.layoutY = (500)


                    uvid.onAction = (e:ActionEvent) => {

                      //   PETA SCENA - UVID U RAD

                      scene = new Scene{

                        fill = LightBlue


                        var prica = new Label ()
                        prica.setText("* " + takmicar.getIme() +" " + takmicar.getIndeks)


                        prica.style="""-fx-font-size: 18pt;
                  -fx-text-fill:  #0000ff;"""
                        prica.layoutX = (70)
                        prica.layoutY = (60)

                        var osvojeni_poeni=2.0
                        if(dugme==2)
                          osvojeni_poeni=2.5

                        var poeni = new Label ()
                        if(dugme == 1)
                          poeni.setText("* Broj osvojenih poena na kolokvijumu: " + takmicar.getBodovi() + "\n* Ovako izgleda Vas rad:")
                        else if(dugme ==2)
                          poeni.setText("* Broj osvojenih poena na ispitu:" + takmicar.getBodovi() + "\n* Ovako izgleda Vas rad:")

                        poeni.style="""-fx-font-size: 18pt;
                  -fx-text-fill:  #0000ff;"""
                        poeni.layoutX = (70)
                        poeni.layoutY = (90)

                        var l=0
                        var prica2 = new TextArea()
                        prica2.setPrefHeight(300)
                        prica2.setPrefWidth(600)
                        if(kliknuto(0)==1)
                        {
                          prica2.setText( "-1. pitanje: " + listaPitanja2(0).toString() + "\n-Vas odgovor je: " + odgovori(0).toString() + ".\n-To je tacan odgovor!\n-Osvojili ste " + osvojeni_poeni+ " poena! ")
                          l+=1
                        }
                        else if(kliknuto(0)==2)
                        {
                          prica2.setText( "-1. pitanje: " + listaPitanja2(0).toString() + "\n-Vas odgovor je: " + odgovori(0).toString() +  ".\n-To je netacan odgovor!\n-Tacan odgovor je: " + listaPitanja2(0).tacanOdgovor.toString() + ".\n-Niste osvojili poene!")
                          l+=1
                        }
                        else if(kliknuto(0)==0)
                          prica2.setText( "1. pitanje: " + listaPitanja2(0).toString() + "\nNiste dali odgovor! \nTacan odgovor je: " + listaPitanja2(0).tacanOdgovor + ".\nNiste osvojili poene!")



                        prica2.style="""-fx-font-size: 20pt;
                  -fx-text-fill:  #0000ff;"""
                        prica2.layoutX = (50)
                        prica2.layoutY = (190)

                        prica.setWrapText(true)
                        prica2.setWrapText(true)

                        val sledece = new Button ("Sledece")
                        {
                          prefWidth=100
                          prefHeight=80
                          style="""-fx-background-color:  linear-gradient(#bf90ee, #ffc0cb);

                          -fx-background-radius: 5;
                          -fx-background-insets: 0,1,2,3,0;
                          -fx-text-fill: #0000ff;
                          -fx-font-weight: bold;
                          -fx-font-size: 15;"""

                        }
                        sledece.layoutX = 280
                        sledece.layoutY = 550

                        var k=0
                        
                        
                        sledece.onAction = (e: ActionEvent) => {
                          if (k<9){
                            k +=1

                            var m = k+1
                            if(kliknuto(k)==1)
                            {
                              prica2.setText( "- " + m + ". pitanje: " + listaPitanja2(k).toString() + "\n-Vas odgovor je: " + odgovori(k).toString() + ".\n-To je tacan odgovor!\n-Osvojili ste " + osvojeni_poeni + " poena! ")
                              
                            }
                            else if(kliknuto(k)==2)
                            {
                              prica2.setText( "- " + m + ". pitanje: " + listaPitanja2(k).toString() + "\n-Vas odgovor je: " + odgovori(k).toString() +  ".\n-To je netacan odgovor!\n-Tacan odgovor je: " + listaPitanja2(k).tacanOdgovor.toString() + ".\n-Niste osvojili poene!")
                             
                            }
                            else if(kliknuto(k)==0)
                              prica2.setText( "- " + m + ". pitanje: " + listaPitanja2(k).toString() + "\n-Niste dali odgovor! \n-Tacan odgovor je: " + listaPitanja2(k).tacanOdgovor + ".\n-Niste osvojili poene!")
                          }


                          else
                          {  sledece.setText("KRAJ")

                            stage.close
                          }
                        }

                        content = List(prica,poeni,prica2,sledece)
                      }
                    }

                    kraj.onAction = (e:ActionEvent) => {

                      stage.close()

                    }


                    if(dugme==2)
                      content = List(polozio,rezultat,ImeIprezime,ocenalabela, poruka, kraj, uvid)
                    else
                      content = List(rezultat,ImeIprezime,ocenalabela, poruka, kraj, uvid)


                  }
                }
                else
                {
                  j+=1
                  indeks = j+1
                  labela.text = indeks + ". " + listaPitanja2(j).toString()

                  var listaOdgovora3 = scala.collection.mutable.MutableList[String](listaPitanja2(j).tacanOdgovor.toString(),listaPitanja2(j).drugi.toString(),listaPitanja2(j).treci.toString(),listaPitanja2(j).cetvrti.toString())
                  var listaOdgovora4 = scala.util.Random.shuffle(listaOdgovora3)
                  dugme1.text = listaOdgovora4(0)
                  dugme2.text = listaOdgovora4(1)
                  dugme3.text = listaOdgovora4(2)
                  dugme4.text = listaOdgovora4(3)
                  tog.selectToggle(null)
                }
              }




              content = List(dugme1,dugme2,dugme3,dugme4,labela,dugmedalje,tacnoiline)



            }

          }


          content = List(imeIprezime, imePrezime, brojIndeksa, indeks, odabir, kolokvijum, ispit, recenica, brojPoenaT, brojT, brojPoenaP, brojP, brojPoenaI, brojI, srecno, start)
        }

      }
      content = List(labela,pocni)


    }




  }

}