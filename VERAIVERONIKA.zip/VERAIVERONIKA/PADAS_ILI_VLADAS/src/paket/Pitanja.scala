package paket

object
Pitanja {


  class Pitanja(var ime: String, var tacanOdgovor: String, var drugi : String, var treci : String, var cetvrti : String ) {
    this.setIme(ime)

    def getIme(): String = ime

    def getTacanOdgovor(): String = tacanOdgovor
    def getDrugi(): String = drugi
    def getTreci(): String = treci
    def getCetvrti() : String = cetvrti


    def setIme(ime: String) = {
      this.ime = ime
    }


    def setTacanOdgovor(tacanOdgovor: String) = {
      this.tacanOdgovor = tacanOdgovor
    }

    def setDrugi(drugi : String) = {
      this.drugi= drugi
    }

    def setTreci(treci : String) = {
      this.treci= treci
    }

    def setCetvrti(cetvrti : String) = {
      this.cetvrti= cetvrti
    }


    override def toString(): String = {
      return "%s".format(this.ime)
    }






  }




}
